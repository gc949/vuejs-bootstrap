<template>
  <div class="row justify-content-center">
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-10.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-76.gif"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35246</span>
              <h4 class="fw-semibold fs-14 mb-0">Christmas Eve</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">9.75 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">5.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.2<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-11.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-77.gif"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35247</span>
              <h4 class="fw-semibold fs-14 mb-0">Humming Bird</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">10.75 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">12.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.5<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-12.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-85.png"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35228</span>
              <h4 class="fw-semibold fs-14 mb-0">Naughty Pool</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">8.75 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">9.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.7<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-13.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-85.png"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35227</span>
              <h4 class="fw-semibold fs-14 mb-0">Hello Thumbs</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">9.30 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">8.15 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.7<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-14.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-76.gif"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35248</span>
              <h4 class="fw-semibold fs-14 mb-0">Pixel Watermmelon</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">1.75 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">3.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.7<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-3.gif" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-77.gif"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35258</span>
              <h4 class="fw-semibold fs-14 mb-0">BDancing Cookies</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">10.75 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">12.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.7<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-15.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-85.png"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35158</span>
              <h4 class="fw-semibold fs-14 mb-0">Rotating Flower</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1">
                Highest Bid:
                <span class="fw-semibold text-secondary">3.95 ETH</span>
              </span>
              <h4 class="fw-semibold fs-14 mb-0">6.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.7<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
    <div class="col-xxl-3 col-lg-4 col-sm-6">
      <div class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4">
        <RouterLink
          to="/nft-marketplace/nft-details"
          class="d-block mb-3 text-decoration-none position-relative"
        >
          <img src="@/assets/images/nft-16.png" class="rounded-3" alt="nft" />
          <span
            class="btn btn-primary py-2 px-3 d-inline-block fs-16 fw-medium position-absolute top-50 start-50 translate-middle opacity-0"
          >
            Place Bid
          </span>
        </RouterLink>

        <div
          class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3"
        >
          <RouterLink
            to="/nft-marketplace/creator-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-shrink-0">
              <img
                src="@/assets/images/user-85.png"
                class="rounded-circle"
                style="width: 27px; height: 27px"
                alt="user"
              />
            </div>
            <div class="flex-grow-1 ms-2">
              <span class="fs-12">NFT ID: 35782</span>
              <h4 class="fw-semibold fs-14 mb-0">Flying Bulb</h4>
            </div>
          </RouterLink>
          <img
            src="@/assets/images/verify.svg"
            class="cursor"
            alt="verify"
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            data-bs-title="Verified"
          />
        </div>

        <div class="d-flex justify-content-between align-items-center">
          <RouterLink
            to="/nft-marketplace/nft-details"
            class="d-flex align-items-center text-decoration-none"
          >
            <div class="flex-grow-1">
              <span class="fs-12 d-block mb-1"
                >Highest Bid:
                <span class="fw-semibold text-secondary">8.75 ETH</span></span
              >
              <h4 class="fw-semibold fs-14 mb-0">9.50 ETH</h4>
            </div>
          </RouterLink>
          <button class="bg-transparent p-0 border-0">
            <i
              class="ri-heart-fill fs-20 position-relative top-2"
              style="color: #ee3e08"
            ></i>
            <span class="text-secondary fs-12 fw-semibold">
              9.7<span class="text-body">/10</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  </div>

  <Pagination total="30" items="8" class="mb-4" />
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Pagination from "@/components/Common/Pagination.vue";

export default defineComponent({
  name: "ExploreAll",
  components: {
    Pagination,
  },
});
</script>
