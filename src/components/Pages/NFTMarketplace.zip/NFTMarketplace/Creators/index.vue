<template>
  <div class="row justify-content-center">
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-1.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-76.gif"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Hunny Bunny</h4>
          <span class="fs-12">ITEMS: 3204</span>
        </div>
        <button class="btn btn-primary py-2 px-4 fs-16 fw-medium">
          Follow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-2.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-77.gif"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Aristocrat</h4>
          <span class="fs-12">ITEMS: 5301</span>
        </div>
        <button class="btn btn-primary py-2 px-4 fs-16 fw-medium">
          Follow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-3.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-78.gif"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Hooman Robotic</h4>
          <span class="fs-12">ITEMS: 4213</span>
        </div>
        <button class="btn btn-secondary py-2 px-4 fs-16 fw-medium">
          Unfollow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-4.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-98.png"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Colorful Life</h4>
          <span class="fs-12">ITEMS: 2314</span>
        </div>
        <button class="btn btn-primary py-2 px-4 fs-16 fw-medium">
          Follow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-5.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-99.png"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Anne Bunny</h4>
          <span class="fs-12">ITEMS: 4758</span>
        </div>
        <button class="btn btn-secondary py-2 px-4 fs-16 fw-medium">
          Unfollow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-6.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-100.png"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Piterdess</h4>
          <span class="fs-12">ITEMS: 1234</span>
        </div>
        <button class="btn btn-primary py-2 px-4 fs-16 fw-medium">
          Follow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-7.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-101 start-50 translate-middle">
            <img
              src="@/assets/images/user-78.gif"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Alex Smith</h4>
          <span class="fs-12">ITEMS: 8520</span>
        </div>
        <button class="btn btn-secondary py-2 px-4 fs-16 fw-medium">
          Unfollow
        </button>
      </div>
    </div>
    <div class="col-lg-3 col-sm-6 col-md-4">
      <div
        class="bg-white rounded-3 border-0 p-3 place-bid for-dark-card mb-4 text-center"
      >
        <div class="position-relative">
          <img
            src="@/assets/images/top-creator-8.png"
            class="rounded-3"
            alt="top-creator"
          />
          <div class="position-absolute top-100 start-50 translate-middle">
            <img
              src="@/assets/images/user-102.png"
              class="rounded-circle"
              style="width: 64px; height: 64px"
              alt="user"
            />
            <img
              src="@/assets/images/verify.svg"
              class="position-absolute bottom-0 end-0"
              alt="verify"
            />
          </div>
        </div>
        <div class="mt-5 border-bottom pb-3 mb-3">
          <h4 class="fs-16 fw-semibold">Straven Dew</h4>
          <span class="fs-12">ITEMS: 4562</span>
        </div>
        <button class="btn btn-primary py-2 px-4 fs-16 fw-medium">
          Follow
        </button>
      </div>
    </div>
    <div class="col-lg-12">
      <div class="col-lg-12">
        <Pagination total="30" items="08" class="mb-4" />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Pagination from "@/components/Common/Pagination.vue";

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Creators",
  components: {
    Pagination,
  },
});
</script>
